from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    def __repr__(self):
        return f'<User {self.username}>'

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'is_active': self.is_active
        }

class Agent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Configuration fields
    scraping_schedule = db.Column(db.String(50), default='daily')  # daily, weekly, hourly
    positive_actions = db.Column(db.JSON)  # JSON array of actions to perform
    
    # Relationships
    user = db.relationship('User', backref='agents')
    data_sources = db.relationship('DataSource', backref='agent', cascade='all, delete-orphan')
    scraping_jobs = db.relationship('ScrapingJob', backref='agent', cascade='all, delete-orphan')

    def __repr__(self):
        return f'<Agent {self.name}>'

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'user_id': self.user_id,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'scraping_schedule': self.scraping_schedule,
            'positive_actions': self.positive_actions,
            'data_sources': [ds.to_dict() for ds in self.data_sources]
        }

class DataSource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('agent.id'), nullable=False)
    url = db.Column(db.String(500), nullable=False)
    source_type = db.Column(db.String(50), default='webpage')  # webpage, rss, api
    extraction_rules = db.Column(db.JSON)  # JSON object with CSS selectors, XPath, etc.
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<DataSource {self.url}>'

    def to_dict(self):
        return {
            'id': self.id,
            'agent_id': self.agent_id,
            'url': self.url,
            'source_type': self.source_type,
            'extraction_rules': self.extraction_rules,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class ScrapingJob(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('agent.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, running, completed, failed
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    error_message = db.Column(db.Text)
    data_extracted = db.Column(db.JSON)  # JSON object with extracted data
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<ScrapingJob {self.id} - {self.status}>'

    def to_dict(self):
        return {
            'id': self.id,
            'agent_id': self.agent_id,
            'status': self.status,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'error_message': self.error_message,
            'data_extracted': self.data_extracted,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class ActionLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    agent_id = db.Column(db.Integer, db.ForeignKey('agent.id'), nullable=False)
    action_type = db.Column(db.String(50), nullable=False)  # email, webhook, notification, etc.
    action_data = db.Column(db.JSON)  # JSON object with action parameters
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    executed_at = db.Column(db.DateTime)
    error_message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationship
    agent = db.relationship('Agent', backref='action_logs')

    def __repr__(self):
        return f'<ActionLog {self.id} - {self.action_type}>'

    def to_dict(self):
        return {
            'id': self.id,
            'agent_id': self.agent_id,
            'action_type': self.action_type,
            'action_data': self.action_data,
            'status': self.status,
            'executed_at': self.executed_at.isoformat() if self.executed_at else None,
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

