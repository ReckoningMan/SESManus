import asyncio
import random
import time
import urllib.robotparser
from typing import Dict, List, Optional, Any
from urllib.parse import urljoin, urlparse
from datetime import datetime

import requests
from bs4 import BeautifulSoup
from fake_useragent import UserAgent
from playwright.async_api import async_playwright, Browser, Page

class ScrapingEngine:
    """
    Advanced web scraping engine with user agent rotation, proxy support,
    rate limiting, and robots.txt compliance.
    """
    
    def __init__(self):
        self.ua = UserAgent()
        self.session = requests.Session()
        self.browser: Optional[Browser] = None
        self.playwright = None
        
        # Rate limiting settings
        self.min_delay = 1.0  # Minimum delay between requests (seconds)
        self.max_delay = 3.0  # Maximum delay between requests (seconds)
        self.last_request_time = 0
        
        # User agent pool for rotation
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0',
        ]
    
    def get_random_user_agent(self) -> str:
        """Get a random user agent string."""
        try:
            return self.ua.random
        except:
            # Fallback to predefined user agents if fake_useragent fails
            return random.choice(self.user_agents)
    
    def check_robots_txt(self, url: str, user_agent: str = '*') -> bool:
        """
        Check if scraping is allowed according to robots.txt.
        
        Args:
            url: The URL to check
            user_agent: User agent string to check against
            
        Returns:
            True if scraping is allowed, False otherwise
        """
        try:
            parsed_url = urlparse(url)
            robots_url = f"{parsed_url.scheme}://{parsed_url.netloc}/robots.txt"
            
            rp = urllib.robotparser.RobotFileParser()
            rp.set_url(robots_url)
            rp.read()
            
            return rp.can_fetch(user_agent, url)
        except Exception as e:
            print(f"Error checking robots.txt for {url}: {e}")
            # If we can't check robots.txt, assume it's allowed but be cautious
            return True
    
    def apply_rate_limiting(self):
        """Apply rate limiting between requests."""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        
        delay = random.uniform(self.min_delay, self.max_delay)
        
        if time_since_last_request < delay:
            sleep_time = delay - time_since_last_request
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def scrape_with_requests(self, url: str, extraction_rules: Dict[str, Any]) -> Dict[str, Any]:
        """
        Scrape a webpage using requests and BeautifulSoup.
        
        Args:
            url: URL to scrape
            extraction_rules: Dictionary containing CSS selectors and extraction rules
            
        Returns:
            Dictionary containing extracted data
        """
        try:
            # Check robots.txt compliance
            user_agent = self.get_random_user_agent()
            if not self.check_robots_txt(url, user_agent):
                return {
                    'error': 'Scraping not allowed by robots.txt',
                    'url': url,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            # Apply rate limiting
            self.apply_rate_limiting()
            
            # Set headers with random user agent
            headers = {
                'User-Agent': user_agent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            }
            
            # Make the request
            response = self.session.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            
            # Parse the HTML
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract data based on rules
            extracted_data = self.extract_data_from_soup(soup, extraction_rules)
            extracted_data.update({
                'url': url,
                'timestamp': datetime.utcnow().isoformat(),
                'status_code': response.status_code,
                'method': 'requests'
            })
            
            return extracted_data
            
        except Exception as e:
            return {
                'error': str(e),
                'url': url,
                'timestamp': datetime.utcnow().isoformat(),
                'method': 'requests'
            }
    
    async def scrape_with_playwright(self, url: str, extraction_rules: Dict[str, Any]) -> Dict[str, Any]:
        """
        Scrape a webpage using Playwright for dynamic content.
        
        Args:
            url: URL to scrape
            extraction_rules: Dictionary containing CSS selectors and extraction rules
            
        Returns:
            Dictionary containing extracted data
        """
        try:
            # Check robots.txt compliance
            user_agent = self.get_random_user_agent()
            if not self.check_robots_txt(url, user_agent):
                return {
                    'error': 'Scraping not allowed by robots.txt',
                    'url': url,
                    'timestamp': datetime.utcnow().isoformat()
                }
            
            # Apply rate limiting
            self.apply_rate_limiting()
            
            # Initialize Playwright if not already done
            if not self.playwright:
                self.playwright = await async_playwright().start()
                self.browser = await self.playwright.chromium.launch(headless=True)
            
            # Create a new page with random user agent
            page = await self.browser.new_page(user_agent=user_agent)
            
            # Navigate to the page
            await page.goto(url, wait_until='networkidle', timeout=30000)
            
            # Wait for any dynamic content to load
            await page.wait_for_timeout(2000)
            
            # Get page content
            content = await page.content()
            soup = BeautifulSoup(content, 'html.parser')
            
            # Extract data based on rules
            extracted_data = self.extract_data_from_soup(soup, extraction_rules)
            extracted_data.update({
                'url': url,
                'timestamp': datetime.utcnow().isoformat(),
                'method': 'playwright'
            })
            
            await page.close()
            return extracted_data
            
        except Exception as e:
            return {
                'error': str(e),
                'url': url,
                'timestamp': datetime.utcnow().isoformat(),
                'method': 'playwright'
            }
    
    def extract_data_from_soup(self, soup: BeautifulSoup, extraction_rules: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract data from BeautifulSoup object based on extraction rules.
        
        Args:
            soup: BeautifulSoup object
            extraction_rules: Dictionary containing extraction rules
            
        Returns:
            Dictionary containing extracted data
        """
        extracted_data = {}
        
        for field_name, rule in extraction_rules.items():
            try:
                if isinstance(rule, str):
                    # Simple CSS selector
                    elements = soup.select(rule)
                    if elements:
                        if len(elements) == 1:
                            extracted_data[field_name] = elements[0].get_text(strip=True)
                        else:
                            extracted_data[field_name] = [elem.get_text(strip=True) for elem in elements]
                    else:
                        extracted_data[field_name] = None
                        
                elif isinstance(rule, dict):
                    # Complex extraction rule
                    selector = rule.get('selector')
                    attribute = rule.get('attribute', 'text')
                    multiple = rule.get('multiple', False)
                    
                    if selector:
                        elements = soup.select(selector)
                        if elements:
                            if attribute == 'text':
                                values = [elem.get_text(strip=True) for elem in elements]
                            else:
                                values = [elem.get(attribute) for elem in elements if elem.get(attribute)]
                            
                            if multiple:
                                extracted_data[field_name] = values
                            else:
                                extracted_data[field_name] = values[0] if values else None
                        else:
                            extracted_data[field_name] = None
                            
            except Exception as e:
                extracted_data[field_name] = f"Extraction error: {str(e)}"
        
        return extracted_data
    
    async def scrape_url(self, url: str, extraction_rules: Dict[str, Any], use_browser: bool = False) -> Dict[str, Any]:
        """
        Main scraping method that chooses between requests and Playwright.
        
        Args:
            url: URL to scrape
            extraction_rules: Dictionary containing extraction rules
            use_browser: Whether to use Playwright for dynamic content
            
        Returns:
            Dictionary containing extracted data
        """
        if use_browser:
            return await self.scrape_with_playwright(url, extraction_rules)
        else:
            return self.scrape_with_requests(url, extraction_rules)
    
    async def close(self):
        """Clean up resources."""
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        self.session.close()

class DataProcessor:
    """
    Data processing and cleaning utilities for scraped content.
    """
    
    @staticmethod
    def clean_text(text: str) -> str:
        """Clean and normalize text content."""
        if not text:
            return ""
        
        # Remove extra whitespace and normalize
        text = ' '.join(text.split())
        
        # Remove common unwanted characters
        text = text.replace('\u00a0', ' ')  # Non-breaking space
        text = text.replace('\u200b', '')   # Zero-width space
        
        return text.strip()
    
    @staticmethod
    def validate_url(url: str) -> bool:
        """Validate if a URL is properly formatted."""
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except:
            return False
    
    @staticmethod
    def extract_domain(url: str) -> str:
        """Extract domain from URL."""
        try:
            return urlparse(url).netloc
        except:
            return ""
    
    @staticmethod
    def process_scraped_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Process and clean scraped data.
        
        Args:
            data: Raw scraped data
            
        Returns:
            Processed and cleaned data
        """
        processed_data = {}
        
        for key, value in data.items():
            if isinstance(value, str):
                processed_data[key] = DataProcessor.clean_text(value)
            elif isinstance(value, list):
                processed_data[key] = [
                    DataProcessor.clean_text(item) if isinstance(item, str) else item
                    for item in value
                ]
            else:
                processed_data[key] = value
        
        return processed_data

# Example usage and testing
async def test_scraping_engine():
    """Test the scraping engine with a sample website."""
    engine = ScrapingEngine()
    
    # Test with a simple website
    url = "https://httpbin.org/html"
    extraction_rules = {
        'title': 'title',
        'headings': {'selector': 'h1', 'multiple': True},
        'paragraphs': {'selector': 'p', 'multiple': True}
    }
    
    # Test with requests
    print("Testing with requests...")
    result = engine.scrape_with_requests(url, extraction_rules)
    print(f"Requests result: {result}")
    
    # Test with Playwright
    print("\nTesting with Playwright...")
    result = await engine.scrape_with_playwright(url, extraction_rules)
    print(f"Playwright result: {result}")
    
    await engine.close()

if __name__ == "__main__":
    asyncio.run(test_scraping_engine())

