#!/bin/bash

echo "🛑 Stopping Agent Maker..."
pkill -f gunicorn
echo "✅ Agent Maker stopped"

