from flask import Blueprint, jsonify, request
from src.models.user import Agent, DataSource, ScrapingJob, ActionLog, db
from datetime import datetime

agent_bp = Blueprint('agent', __name__)

@agent_bp.route('/agents', methods=['GET'])
def get_agents():
    """Get all agents for the current user"""
    # For now, we'll get all agents. In a real app, filter by user_id
    agents = Agent.query.all()
    return jsonify([agent.to_dict() for agent in agents])

@agent_bp.route('/agents', methods=['POST'])
def create_agent():
    """Create a new agent"""
    data = request.json
    
    # Validate required fields
    if not data.get('name'):
        return jsonify({'error': 'Agent name is required'}), 400
    
    if not data.get('user_id'):
        return jsonify({'error': 'User ID is required'}), 400
    
    agent = Agent(
        name=data['name'],
        description=data.get('description', ''),
        user_id=data['user_id'],
        scraping_schedule=data.get('scraping_schedule', 'daily'),
        positive_actions=data.get('positive_actions', [])
    )
    
    db.session.add(agent)
    db.session.commit()
    
    return jsonify(agent.to_dict()), 201

@agent_bp.route('/agents/<int:agent_id>', methods=['GET'])
def get_agent(agent_id):
    """Get a specific agent by ID"""
    agent = Agent.query.get_or_404(agent_id)
    return jsonify(agent.to_dict())

@agent_bp.route('/agents/<int:agent_id>', methods=['PUT'])
def update_agent(agent_id):
    """Update an existing agent"""
    agent = Agent.query.get_or_404(agent_id)
    data = request.json
    
    agent.name = data.get('name', agent.name)
    agent.description = data.get('description', agent.description)
    agent.scraping_schedule = data.get('scraping_schedule', agent.scraping_schedule)
    agent.positive_actions = data.get('positive_actions', agent.positive_actions)
    agent.is_active = data.get('is_active', agent.is_active)
    agent.updated_at = datetime.utcnow()
    
    db.session.commit()
    return jsonify(agent.to_dict())

@agent_bp.route('/agents/<int:agent_id>', methods=['DELETE'])
def delete_agent(agent_id):
    """Delete an agent"""
    agent = Agent.query.get_or_404(agent_id)
    db.session.delete(agent)
    db.session.commit()
    return '', 204

@agent_bp.route('/agents/<int:agent_id>/data-sources', methods=['GET'])
def get_agent_data_sources(agent_id):
    """Get all data sources for an agent"""
    agent = Agent.query.get_or_404(agent_id)
    return jsonify([ds.to_dict() for ds in agent.data_sources])

@agent_bp.route('/agents/<int:agent_id>/data-sources', methods=['POST'])
def create_data_source(agent_id):
    """Add a new data source to an agent"""
    agent = Agent.query.get_or_404(agent_id)
    data = request.json
    
    if not data.get('url'):
        return jsonify({'error': 'URL is required'}), 400
    
    data_source = DataSource(
        agent_id=agent_id,
        url=data['url'],
        source_type=data.get('source_type', 'webpage'),
        extraction_rules=data.get('extraction_rules', {})
    )
    
    db.session.add(data_source)
    db.session.commit()
    
    return jsonify(data_source.to_dict()), 201

@agent_bp.route('/data-sources/<int:source_id>', methods=['PUT'])
def update_data_source(source_id):
    """Update a data source"""
    data_source = DataSource.query.get_or_404(source_id)
    data = request.json
    
    data_source.url = data.get('url', data_source.url)
    data_source.source_type = data.get('source_type', data_source.source_type)
    data_source.extraction_rules = data.get('extraction_rules', data_source.extraction_rules)
    data_source.is_active = data.get('is_active', data_source.is_active)
    
    db.session.commit()
    return jsonify(data_source.to_dict())

@agent_bp.route('/data-sources/<int:source_id>', methods=['DELETE'])
def delete_data_source(source_id):
    """Delete a data source"""
    data_source = DataSource.query.get_or_404(source_id)
    db.session.delete(data_source)
    db.session.commit()
    return '', 204

@agent_bp.route('/agents/<int:agent_id>/scraping-jobs', methods=['GET'])
def get_scraping_jobs(agent_id):
    """Get all scraping jobs for an agent"""
    agent = Agent.query.get_or_404(agent_id)
    jobs = ScrapingJob.query.filter_by(agent_id=agent_id).order_by(ScrapingJob.created_at.desc()).all()
    return jsonify([job.to_dict() for job in jobs])

@agent_bp.route('/agents/<int:agent_id>/scraping-jobs', methods=['POST'])
def create_scraping_job(agent_id):
    """Create a new scraping job for an agent"""
    agent = Agent.query.get_or_404(agent_id)
    
    job = ScrapingJob(agent_id=agent_id)
    db.session.add(job)
    db.session.commit()
    
    return jsonify(job.to_dict()), 201

@agent_bp.route('/scraping-jobs/<int:job_id>', methods=['PUT'])
def update_scraping_job(job_id):
    """Update a scraping job status"""
    job = ScrapingJob.query.get_or_404(job_id)
    data = request.json
    
    job.status = data.get('status', job.status)
    job.error_message = data.get('error_message', job.error_message)
    job.data_extracted = data.get('data_extracted', job.data_extracted)
    
    if data.get('status') == 'running' and not job.started_at:
        job.started_at = datetime.utcnow()
    elif data.get('status') in ['completed', 'failed'] and not job.completed_at:
        job.completed_at = datetime.utcnow()
    
    db.session.commit()
    return jsonify(job.to_dict())

@agent_bp.route('/agents/<int:agent_id>/action-logs', methods=['GET'])
def get_action_logs(agent_id):
    """Get all action logs for an agent"""
    agent = Agent.query.get_or_404(agent_id)
    logs = ActionLog.query.filter_by(agent_id=agent_id).order_by(ActionLog.created_at.desc()).all()
    return jsonify([log.to_dict() for log in logs])

@agent_bp.route('/agents/<int:agent_id>/action-logs', methods=['POST'])
def create_action_log(agent_id):
    """Create a new action log"""
    agent = Agent.query.get_or_404(agent_id)
    data = request.json
    
    if not data.get('action_type'):
        return jsonify({'error': 'Action type is required'}), 400
    
    action_log = ActionLog(
        agent_id=agent_id,
        action_type=data['action_type'],
        action_data=data.get('action_data', {}),
        status=data.get('status', 'pending')
    )
    
    db.session.add(action_log)
    db.session.commit()
    
    return jsonify(action_log.to_dict()), 201

