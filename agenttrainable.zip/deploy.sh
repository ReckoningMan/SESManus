#!/bin/bash

# Agent Maker Deployment Script
# This script sets up the Agent Maker system for production deployment

set -e

echo "🤖 Agent Maker Deployment Script"
echo "================================="

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo "❌ Please do not run this script as root"
    exit 1
fi

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check dependencies
echo "📋 Checking dependencies..."

if ! command_exists python3; then
    echo "❌ Python 3 is required but not installed"
    exit 1
fi

if ! command_exists node; then
    echo "❌ Node.js is required but not installed"
    exit 1
fi

if ! command_exists npm; then
    echo "❌ npm is required but not installed"
    exit 1
fi

echo "✅ All dependencies found"

# Set up directories
INSTALL_DIR="${HOME}/agent-maker-production"
BACKEND_DIR="${INSTALL_DIR}/backend"
FRONTEND_DIR="${INSTALL_DIR}/frontend"

echo "📁 Setting up directories..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$BACKEND_DIR"
mkdir -p "$FRONTEND_DIR"

# Copy backend files
echo "📦 Setting up backend..."
cp -r /home/ubuntu/agent-maker/* "$BACKEND_DIR/"

# Set up Python virtual environment
cd "$BACKEND_DIR"
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Install additional production dependencies
pip install gunicorn

# Copy frontend files
echo "🎨 Setting up frontend..."
cp -r /home/ubuntu/agent-maker-frontend/* "$FRONTEND_DIR/"

# Build frontend for production
cd "$FRONTEND_DIR"
pnpm install
pnpm run build

# Create production configuration
echo "⚙️ Creating production configuration..."

cat > "$BACKEND_DIR/production_config.py" << EOF
import os

class ProductionConfig:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'production-secret-key-change-this')
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///production.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    DEBUG = False
    TESTING = False
    
    # CORS settings for production
    CORS_ORIGINS = ['*']  # Configure this for your domain
    
    # Scraping settings
    SCRAPING_RATE_LIMIT = 1  # seconds between requests
    MAX_CONCURRENT_JOBS = 5
    
    # Security settings
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
EOF

# Create systemd service file
echo "🔧 Creating systemd service..."

cat > "$INSTALL_DIR/agent-maker.service" << EOF
[Unit]
Description=Agent Maker Backend Service
After=network.target

[Service]
Type=exec
User=$USER
WorkingDirectory=$BACKEND_DIR
Environment=PATH=$BACKEND_DIR/venv/bin
Environment=FLASK_ENV=production
ExecStart=$BACKEND_DIR/venv/bin/gunicorn --bind 0.0.0.0:5001 --workers 4 src.main:app
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# Create nginx configuration
echo "🌐 Creating nginx configuration..."

cat > "$INSTALL_DIR/nginx.conf" << EOF
server {
    listen 80;
    server_name your-domain.com;  # Change this to your domain
    
    # Frontend static files
    location / {
        root $FRONTEND_DIR/dist;
        try_files \$uri \$uri/ /index.html;
    }
    
    # Backend API
    location /api/ {
        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # WebSocket support for real-time features
    location /ws/ {
        proxy_pass http://127.0.0.1:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

# Create startup script
echo "🚀 Creating startup script..."

cat > "$INSTALL_DIR/start.sh" << 'EOF'
#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"

echo "🤖 Starting Agent Maker..."

# Start backend
cd "$BACKEND_DIR"
source venv/bin/activate

# Initialize database
python -c "
from src.main import app
from src.models.user import db
with app.app_context():
    db.create_all()
    print('Database initialized')
"

# Start the application
echo "🚀 Starting backend server..."
gunicorn --bind 0.0.0.0:5001 --workers 4 --daemon src.main:app

echo "✅ Agent Maker started successfully!"
echo "📱 Frontend: http://localhost (if nginx is configured)"
echo "🔧 Backend API: http://localhost:5001/api"
echo ""
echo "To stop the service, run: pkill -f gunicorn"
EOF

chmod +x "$INSTALL_DIR/start.sh"

# Create stop script
cat > "$INSTALL_DIR/stop.sh" << 'EOF'
#!/bin/bash

echo "🛑 Stopping Agent Maker..."
pkill -f gunicorn
echo "✅ Agent Maker stopped"
EOF

chmod +x "$INSTALL_DIR/stop.sh"

# Create embedding widget
echo "🔗 Creating embeddable widget..."

mkdir -p "$INSTALL_DIR/embed"

cat > "$INSTALL_DIR/embed/agent-maker-widget.js" << 'EOF'
(function() {
    'use strict';
    
    // Agent Maker Embeddable Widget
    class AgentMakerWidget {
        constructor(options = {}) {
            this.apiUrl = options.apiUrl || 'http://localhost:5001/api';
            this.containerId = options.containerId || 'agent-maker-widget';
            this.agentId = options.agentId;
            this.theme = options.theme || 'light';
            
            this.init();
        }
        
        init() {
            const container = document.getElementById(this.containerId);
            if (!container) {
                console.error('Agent Maker Widget: Container not found');
                return;
            }
            
            this.render(container);
            this.bindEvents();
        }
        
        render(container) {
            container.innerHTML = `
                <div class="agent-maker-widget ${this.theme}">
                    <div class="widget-header">
                        <h3>🤖 Agent Maker</h3>
                        <button class="widget-toggle">−</button>
                    </div>
                    <div class="widget-content">
                        <div class="agent-status">
                            <span class="status-indicator"></span>
                            <span class="status-text">Loading...</span>
                        </div>
                        <div class="agent-actions">
                            <button class="btn-run" disabled>Run Agent</button>
                            <button class="btn-configure">Configure</button>
                        </div>
                        <div class="agent-logs">
                            <div class="log-entry">Widget initialized</div>
                        </div>
                    </div>
                </div>
            `;
            
            this.addStyles();
            this.loadAgentStatus();
        }
        
        addStyles() {
            if (document.getElementById('agent-maker-widget-styles')) return;
            
            const styles = `
                .agent-maker-widget {
                    position: fixed;
                    bottom: 20px;
                    right: 20px;
                    width: 300px;
                    background: white;
                    border: 1px solid #e2e8f0;
                    border-radius: 12px;
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                    z-index: 10000;
                }
                
                .agent-maker-widget.dark {
                    background: #2d3748;
                    border-color: #4a5568;
                    color: white;
                }
                
                .widget-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 15px;
                    border-bottom: 1px solid #e2e8f0;
                    background: #f7fafc;
                    border-radius: 12px 12px 0 0;
                }
                
                .widget-header h3 {
                    margin: 0;
                    font-size: 16px;
                    font-weight: 600;
                }
                
                .widget-toggle {
                    background: none;
                    border: none;
                    font-size: 18px;
                    cursor: pointer;
                    padding: 0;
                    width: 24px;
                    height: 24px;
                }
                
                .widget-content {
                    padding: 15px;
                }
                
                .agent-status {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    margin-bottom: 15px;
                }
                
                .status-indicator {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: #gray;
                }
                
                .status-indicator.active {
                    background: #48bb78;
                }
                
                .status-indicator.running {
                    background: #4299e1;
                    animation: pulse 2s infinite;
                }
                
                @keyframes pulse {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.5; }
                }
                
                .agent-actions {
                    display: flex;
                    gap: 8px;
                    margin-bottom: 15px;
                }
                
                .agent-actions button {
                    flex: 1;
                    padding: 8px 12px;
                    border: 1px solid #e2e8f0;
                    border-radius: 6px;
                    background: white;
                    cursor: pointer;
                    font-size: 12px;
                }
                
                .btn-run {
                    background: #48bb78 !important;
                    color: white !important;
                    border-color: #48bb78 !important;
                }
                
                .btn-run:disabled {
                    background: #e2e8f0 !important;
                    color: #a0aec0 !important;
                    cursor: not-allowed !important;
                }
                
                .agent-logs {
                    max-height: 100px;
                    overflow-y: auto;
                    font-size: 11px;
                    color: #718096;
                }
                
                .log-entry {
                    padding: 2px 0;
                    border-bottom: 1px solid #f7fafc;
                }
                
                .widget-collapsed .widget-content {
                    display: none;
                }
            `;
            
            const styleSheet = document.createElement('style');
            styleSheet.id = 'agent-maker-widget-styles';
            styleSheet.textContent = styles;
            document.head.appendChild(styleSheet);
        }
        
        bindEvents() {
            const widget = document.querySelector('.agent-maker-widget');
            const toggle = widget.querySelector('.widget-toggle');
            const runBtn = widget.querySelector('.btn-run');
            const configBtn = widget.querySelector('.btn-configure');
            
            toggle.addEventListener('click', () => {
                widget.classList.toggle('widget-collapsed');
                toggle.textContent = widget.classList.contains('widget-collapsed') ? '+' : '−';
            });
            
            runBtn.addEventListener('click', () => this.runAgent());
            configBtn.addEventListener('click', () => this.openConfiguration());
        }
        
        async loadAgentStatus() {
            if (!this.agentId) {
                this.updateStatus('No agent configured', 'inactive');
                return;
            }
            
            try {
                const response = await fetch(`${this.apiUrl}/agents/${this.agentId}`);
                const agent = await response.json();
                
                this.updateStatus(
                    agent.is_active ? 'Agent active' : 'Agent inactive',
                    agent.is_active ? 'active' : 'inactive'
                );
                
                document.querySelector('.btn-run').disabled = !agent.is_active;
                this.addLog(`Loaded agent: ${agent.name}`);
                
            } catch (error) {
                this.updateStatus('Connection error', 'error');
                this.addLog('Failed to load agent status');
            }
        }
        
        updateStatus(text, status) {
            const statusText = document.querySelector('.status-text');
            const statusIndicator = document.querySelector('.status-indicator');
            
            statusText.textContent = text;
            statusIndicator.className = `status-indicator ${status}`;
        }
        
        addLog(message) {
            const logs = document.querySelector('.agent-logs');
            const entry = document.createElement('div');
            entry.className = 'log-entry';
            entry.textContent = `${new Date().toLocaleTimeString()}: ${message}`;
            logs.appendChild(entry);
            logs.scrollTop = logs.scrollHeight;
        }
        
        async runAgent() {
            if (!this.agentId) return;
            
            this.updateStatus('Running...', 'running');
            this.addLog('Starting scraping job...');
            
            try {
                const response = await fetch(`${this.apiUrl}/scraping/jobs`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ agent_id: this.agentId })
                });
                
                if (response.ok) {
                    this.addLog('Scraping job started successfully');
                    setTimeout(() => this.loadAgentStatus(), 2000);
                } else {
                    throw new Error('Failed to start job');
                }
                
            } catch (error) {
                this.updateStatus('Error', 'error');
                this.addLog('Failed to start scraping job');
            }
        }
        
        openConfiguration() {
            window.open(`${this.apiUrl.replace('/api', '')}`, '_blank');
        }
    }
    
    // Auto-initialize if data attributes are present
    document.addEventListener('DOMContentLoaded', function() {
        const containers = document.querySelectorAll('[data-agent-maker]');
        containers.forEach(container => {
            const options = {
                containerId: container.id,
                agentId: container.dataset.agentId,
                apiUrl: container.dataset.apiUrl,
                theme: container.dataset.theme
            };
            new AgentMakerWidget(options);
        });
    });
    
    // Export for manual initialization
    window.AgentMakerWidget = AgentMakerWidget;
})();
EOF

# Create embedding example
cat > "$INSTALL_DIR/embed/example.html" << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Maker Widget Example</title>
</head>
<body>
    <h1>My Website</h1>
    <p>This is an example of how to embed the Agent Maker widget on your website.</p>
    
    <!-- Method 1: Auto-initialization with data attributes -->
    <div id="agent-widget-1" 
         data-agent-maker
         data-agent-id="1"
         data-api-url="http://localhost:5001/api"
         data-theme="light">
    </div>
    
    <!-- Method 2: Manual initialization -->
    <div id="agent-widget-2"></div>
    
    <script src="agent-maker-widget.js"></script>
    <script>
        // Manual initialization example
        new AgentMakerWidget({
            containerId: 'agent-widget-2',
            agentId: 1,
            apiUrl: 'http://localhost:5001/api',
            theme: 'dark'
        });
    </script>
</body>
</html>
EOF

echo ""
echo "✅ Agent Maker deployment setup complete!"
echo ""
echo "📁 Installation directory: $INSTALL_DIR"
echo ""
echo "🚀 To start the system:"
echo "   cd $INSTALL_DIR && ./start.sh"
echo ""
echo "🛑 To stop the system:"
echo "   cd $INSTALL_DIR && ./stop.sh"
echo ""
echo "🔗 Embedding widget:"
echo "   Include: $INSTALL_DIR/embed/agent-maker-widget.js"
echo "   Example: $INSTALL_DIR/embed/example.html"
echo ""
echo "⚙️ Configuration files:"
echo "   Backend: $INSTALL_DIR/backend/production_config.py"
echo "   Nginx: $INSTALL_DIR/nginx.conf"
echo "   Systemd: $INSTALL_DIR/agent-maker.service"
echo ""
echo "📚 Next steps:"
echo "   1. Review and customize configuration files"
echo "   2. Set up nginx (copy nginx.conf to /etc/nginx/sites-available/)"
echo "   3. Install systemd service (sudo cp agent-maker.service /etc/systemd/system/)"
echo "   4. Start the system with ./start.sh"
echo "   5. Test the embedding widget with the example HTML"
echo ""




# Create a simple launcher script for the user
cat > "$INSTALL_DIR/launch_agent_maker.sh" << EOF
#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "Starting Agent Maker... Please wait."

# Run the start script and keep the terminal open
"$SCRIPT_DIR/start.sh"

# Keep the terminal open after the start.sh script finishes
read -p "Press Enter to close this window..."
EOF

chmod +x "$INSTALL_DIR/launch_agent_maker.sh"

echo ""
echo "✅ Launcher script created: $INSTALL_DIR/launch_agent_maker.sh"
echo "   You can create a desktop shortcut to this file on your dedicated laptop."
echo ""
echo "📚 Next steps for your dedicated laptop:"
echo "   1. Copy the entire 
   2. Make sure the 'launch_agent_maker.sh' script is executable (chmod +x)"
echo "   3. Double-click 'launch_agent_maker.sh' to start the Agent Maker."
echo "   4. The script will display the IP address and port to access the dashboard."
echo "   5. From your work computer, open a web browser and go to the displayed address."


