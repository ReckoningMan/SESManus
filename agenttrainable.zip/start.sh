#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
FRONTEND_DIR="$SCRIPT_DIR/frontend"

echo "🤖 Starting Agent Maker..."

# Stop any previously running instances
pkill -f gunicorn || true
pkill -f "python -m http.server" || true

# Start backend
cd "$BACKEND_DIR"
source venv/bin/activate

# Initialize database (if not already)
python -c "
from src.main import app
from src.models.user import db
with app.app_context():
    db.create_all()
    print(\'Database initialized\')
"

# Start the backend with Gunicorn in the background
# Using 0.0.0.0 to bind to all available network interfaces
# Using port 5001 for the backend API
exec $BACKEND_DIR/venv/bin/gunicorn --bind 0.0.0.0:5001 --workers 4 src.main:app --daemon

# Start frontend static file server in the background
# Using port 8080 for the frontend web interface
cd "$FRONTEND_DIR/dist"
exec python3 -m http.server 8080 --bind 0.0.0.0 &

# Give servers a moment to start
sleep 5

# Get the local IP address
LOCAL_IP=$(hostname -I | awk \'{print $1; exit}\')

echo "✅ Agent Maker started successfully!"
echo ""
echo "To access the Agent Maker from another computer, open a web browser and go to:"
echo ""
echo "🌐 Frontend Dashboard: http://${LOCAL_IP}:8080"
echo "🔧 Backend API (for advanced users/integrations): http://${LOCAL_IP}:5001/api"
echo ""
echo "To stop the service, run: $SCRIPT_DIR/stop.sh"

# Keep the script running to display output until manually stopped
wait

