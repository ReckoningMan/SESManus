from flask import Blueprint, jsonify, request
from src.models.user import ScrapingJob, Agent, DataSource, db
from src.scraping_engine import ScrapingEngine, DataProcessor
from datetime import datetime
import asyncio
import threading

scraping_bp = Blueprint('scraping', __name__)

# Global scraping engine instance
scraping_engine = ScrapingEngine()

def run_async_scraping(job_id: int, agent_id: int):
    """
    Run scraping job asynchronously in a separate thread.
    
    Args:
        job_id: ID of the scraping job
        agent_id: ID of the agent
    """
    async def scrape_job():
        try:
            # Get the job and agent from database
            job = ScrapingJob.query.get(job_id)
            agent = Agent.query.get(agent_id)
            
            if not job or not agent:
                return
            
            # Update job status to running
            job.status = 'running'
            job.started_at = datetime.utcnow()
            db.session.commit()
            
            all_extracted_data = []
            
            # Scrape each data source
            for data_source in agent.data_sources:
                if not data_source.is_active:
                    continue
                
                try:
                    # Determine if we need to use browser for dynamic content
                    use_browser = data_source.source_type == 'dynamic' or 'javascript' in str(data_source.extraction_rules).lower()
                    
                    # Perform scraping
                    result = await scraping_engine.scrape_url(
                        data_source.url,
                        data_source.extraction_rules or {},
                        use_browser=use_browser
                    )
                    
                    # Process the data
                    processed_result = DataProcessor.process_scraped_data(result)
                    processed_result['data_source_id'] = data_source.id
                    processed_result['data_source_url'] = data_source.url
                    
                    all_extracted_data.append(processed_result)
                    
                except Exception as e:
                    error_result = {
                        'error': str(e),
                        'data_source_id': data_source.id,
                        'data_source_url': data_source.url,
                        'timestamp': datetime.utcnow().isoformat()
                    }
                    all_extracted_data.append(error_result)
            
            # Update job with results
            job.status = 'completed'
            job.completed_at = datetime.utcnow()
            job.data_extracted = all_extracted_data
            db.session.commit()
            
        except Exception as e:
            # Update job with error
            job = ScrapingJob.query.get(job_id)
            if job:
                job.status = 'failed'
                job.completed_at = datetime.utcnow()
                job.error_message = str(e)
                db.session.commit()
    
    # Run the async function in a new event loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(scrape_job())
    finally:
        loop.close()

@scraping_bp.route('/scraping/jobs', methods=['POST'])
def create_scraping_job():
    """Create a new scraping job for an agent."""
    data = request.json
    agent_id = data.get('agent_id')
    
    if not agent_id:
        return jsonify({'error': 'Agent ID is required'}), 400
    
    agent = Agent.query.get_or_404(agent_id)
    
    # Create new scraping job
    job = ScrapingJob(agent_id=agent_id)
    db.session.add(job)
    db.session.commit()
    
    # Start scraping in background thread
    thread = threading.Thread(target=run_async_scraping, args=(job.id, agent_id))
    thread.daemon = True
    thread.start()
    
    return jsonify(job.to_dict()), 201

@scraping_bp.route('/scraping/jobs/<int:job_id>', methods=['GET'])
def get_scraping_job(job_id):
    """Get details of a specific scraping job."""
    job = ScrapingJob.query.get_or_404(job_id)
    return jsonify(job.to_dict())

@scraping_bp.route('/scraping/test', methods=['POST'])
def test_scraping():
    """Test scraping a single URL with given extraction rules."""
    data = request.json
    url = data.get('url')
    extraction_rules = data.get('extraction_rules', {})
    use_browser = data.get('use_browser', False)
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    if not DataProcessor.validate_url(url):
        return jsonify({'error': 'Invalid URL format'}), 400
    
    async def test_scrape():
        try:
            result = await scraping_engine.scrape_url(url, extraction_rules, use_browser)
            processed_result = DataProcessor.process_scraped_data(result)
            return processed_result
        except Exception as e:
            return {'error': str(e), 'url': url, 'timestamp': datetime.utcnow().isoformat()}
    
    # Run the async function
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        result = loop.run_until_complete(test_scrape())
        return jsonify(result)
    finally:
        loop.close()

@scraping_bp.route('/scraping/validate-url', methods=['POST'])
def validate_url():
    """Validate if a URL is accessible and check robots.txt compliance."""
    data = request.json
    url = data.get('url')
    
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    # Validate URL format
    if not DataProcessor.validate_url(url):
        return jsonify({
            'valid': False,
            'error': 'Invalid URL format',
            'url': url
        })
    
    # Check robots.txt compliance
    user_agent = scraping_engine.get_random_user_agent()
    robots_allowed = scraping_engine.check_robots_txt(url, user_agent)
    
    # Extract domain
    domain = DataProcessor.extract_domain(url)
    
    return jsonify({
        'valid': True,
        'robots_allowed': robots_allowed,
        'domain': domain,
        'url': url,
        'user_agent_used': user_agent
    })

@scraping_bp.route('/scraping/engines/status', methods=['GET'])
def get_scraping_engine_status():
    """Get the status of the scraping engine."""
    return jsonify({
        'status': 'active',
        'browser_initialized': scraping_engine.browser is not None,
        'playwright_initialized': scraping_engine.playwright is not None,
        'rate_limiting': {
            'min_delay': scraping_engine.min_delay,
            'max_delay': scraping_engine.max_delay,
            'last_request_time': scraping_engine.last_request_time
        }
    })

