import json
import re
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass, asdict
from src.models.user import Agent, DataSource, ScrapingJob, db

@dataclass
class UIAction:
    """Represents a UI action that can be recorded and replayed."""
    action_type: str  # click, input, scroll, wait, etc.
    selector: str     # CSS selector or XPath
    value: Optional[str] = None  # For input actions
    coordinates: Optional[Tuple[int, int]] = None  # For coordinate-based actions
    timestamp: Optional[str] = None
    description: Optional[str] = None

@dataclass
class TrainingSession:
    """Represents a training session for an agent."""
    agent_id: int
    session_id: str
    actions: List[UIAction]
    url: str
    created_at: str
    completed: bool = False
    extraction_rules: Optional[Dict[str, Any]] = None

class AgentTrainer:
    """
    System for training agents through user demonstrations and pattern recognition.
    """
    
    def __init__(self):
        self.training_sessions: Dict[str, TrainingSession] = {}
        self.common_patterns = self._load_common_patterns()
    
    def _load_common_patterns(self) -> Dict[str, Any]:
        """Load common extraction patterns for different website types."""
        return {
            'news_sites': {
                'title_selectors': ['h1', '.title', '.headline', '[data-testid="headline"]', '.entry-title'],
                'content_selectors': ['.content', '.article-body', '.post-content', '.entry-content', 'article p'],
                'date_selectors': ['.date', '.published', '.timestamp', 'time', '.post-date'],
                'author_selectors': ['.author', '.byline', '.writer', '.post-author']
            },
            'e_commerce': {
                'product_title': ['h1', '.product-title', '.item-title', '.product-name'],
                'price': ['.price', '.cost', '.amount', '[data-testid="price"]'],
                'description': ['.description', '.product-description', '.item-details'],
                'reviews': ['.review', '.rating', '.stars', '.feedback']
            },
            'social_media': {
                'posts': ['.post', '.tweet', '.status', '.update'],
                'usernames': ['.username', '.handle', '.user', '.author'],
                'timestamps': ['.time', '.date', '.timestamp', 'time'],
                'content': ['.content', '.text', '.message', '.post-text']
            },
            'forums': {
                'thread_title': ['h1', '.thread-title', '.topic-title'],
                'posts': ['.post', '.message', '.reply'],
                'usernames': ['.username', '.author', '.poster'],
                'post_content': ['.post-content', '.message-body', '.reply-text']
            }
        }
    
    def start_training_session(self, agent_id: int, url: str) -> str:
        """
        Start a new training session for an agent.
        
        Args:
            agent_id: ID of the agent to train
            url: URL where the training will take place
            
        Returns:
            Session ID for the training session
        """
        session_id = f"training_{agent_id}_{int(datetime.utcnow().timestamp())}"
        
        session = TrainingSession(
            agent_id=agent_id,
            session_id=session_id,
            actions=[],
            url=url,
            created_at=datetime.utcnow().isoformat()
        )
        
        self.training_sessions[session_id] = session
        return session_id
    
    def record_action(self, session_id: str, action: UIAction) -> bool:
        """
        Record a UI action in the training session.
        
        Args:
            session_id: ID of the training session
            action: UI action to record
            
        Returns:
            True if action was recorded successfully
        """
        if session_id not in self.training_sessions:
            return False
        
        action.timestamp = datetime.utcnow().isoformat()
        self.training_sessions[session_id].actions.append(action)
        return True
    
    def complete_training_session(self, session_id: str, extraction_rules: Dict[str, Any]) -> bool:
        """
        Complete a training session and save the learned patterns.
        
        Args:
            session_id: ID of the training session
            extraction_rules: Final extraction rules learned from the session
            
        Returns:
            True if session was completed successfully
        """
        if session_id not in self.training_sessions:
            return False
        
        session = self.training_sessions[session_id]
        session.completed = True
        session.extraction_rules = extraction_rules
        
        # Save the training data to the agent
        agent = Agent.query.get(session.agent_id)
        if agent:
            # Store training data in agent's configuration
            training_data = {
                'sessions': [asdict(session)],
                'learned_patterns': extraction_rules,
                'last_training': datetime.utcnow().isoformat()
            }
            
            # Update agent's positive actions to include the learned behavior
            if not agent.positive_actions:
                agent.positive_actions = []
            
            agent.positive_actions.append({
                'type': 'trained_extraction',
                'training_session_id': session_id,
                'extraction_rules': extraction_rules,
                'url_pattern': self._extract_url_pattern(session.url)
            })
            
            db.session.commit()
        
        return True
    
    def _extract_url_pattern(self, url: str) -> str:
        """Extract a URL pattern that can match similar URLs."""
        # Simple pattern extraction - can be made more sophisticated
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return f"{parsed.scheme}://{parsed.netloc}/*"
    
    def suggest_extraction_rules(self, url: str, html_content: str) -> Dict[str, Any]:
        """
        Suggest extraction rules based on URL and content analysis.
        
        Args:
            url: URL of the webpage
            html_content: HTML content of the webpage
            
        Returns:
            Dictionary of suggested extraction rules
        """
        suggestions = {}
        
        # Detect website type based on URL and content
        website_type = self._detect_website_type(url, html_content)
        
        if website_type in self.common_patterns:
            patterns = self.common_patterns[website_type]
            
            # Test each pattern against the HTML content
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html_content, 'html.parser')
            
            for field, selectors in patterns.items():
                for selector in selectors:
                    elements = soup.select(selector)
                    if elements:
                        suggestions[field] = {
                            'selector': selector,
                            'confidence': len(elements),
                            'sample_text': elements[0].get_text(strip=True)[:100] if elements[0].get_text(strip=True) else None
                        }
                        break
        
        return suggestions
    
    def _detect_website_type(self, url: str, html_content: str) -> str:
        """
        Detect the type of website based on URL and content.
        
        Args:
            url: URL of the webpage
            html_content: HTML content of the webpage
            
        Returns:
            Detected website type
        """
        url_lower = url.lower()
        content_lower = html_content.lower()
        
        # Check for e-commerce indicators
        if any(keyword in url_lower for keyword in ['shop', 'store', 'buy', 'cart', 'product']):
            return 'e_commerce'
        if any(keyword in content_lower for keyword in ['add to cart', 'buy now', 'price', '$', '€', '£']):
            return 'e_commerce'
        
        # Check for news site indicators
        if any(keyword in url_lower for keyword in ['news', 'article', 'blog', 'post']):
            return 'news_sites'
        if any(keyword in content_lower for keyword in ['published', 'author', 'article', 'breaking']):
            return 'news_sites'
        
        # Check for social media indicators
        if any(keyword in url_lower for keyword in ['twitter', 'facebook', 'instagram', 'linkedin', 'social']):
            return 'social_media'
        if any(keyword in content_lower for keyword in ['tweet', 'post', 'share', 'like', 'follow']):
            return 'social_media'
        
        # Check for forum indicators
        if any(keyword in url_lower for keyword in ['forum', 'discussion', 'thread', 'topic']):
            return 'forums'
        if any(keyword in content_lower for keyword in ['reply', 'thread', 'forum', 'discussion']):
            return 'forums'
        
        return 'general'
    
    def optimize_extraction_rules(self, agent_id: int, feedback_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Optimize extraction rules based on user feedback and performance data.
        
        Args:
            agent_id: ID of the agent
            feedback_data: List of feedback entries with success/failure information
            
        Returns:
            Optimized extraction rules
        """
        agent = Agent.query.get(agent_id)
        if not agent:
            return {}
        
        # Analyze feedback to identify patterns
        successful_extractions = [f for f in feedback_data if f.get('success', False)]
        failed_extractions = [f for f in feedback_data if not f.get('success', False)]
        
        optimized_rules = {}
        
        # If we have successful extractions, learn from them
        if successful_extractions:
            # Extract common patterns from successful extractions
            for extraction in successful_extractions:
                rules = extraction.get('extraction_rules', {})
                for field, rule in rules.items():
                    if field not in optimized_rules:
                        optimized_rules[field] = []
                    optimized_rules[field].append(rule)
        
        # Remove patterns that frequently fail
        if failed_extractions:
            failed_patterns = set()
            for extraction in failed_extractions:
                rules = extraction.get('extraction_rules', {})
                for field, rule in rules.items():
                    if isinstance(rule, str):
                        failed_patterns.add(rule)
                    elif isinstance(rule, dict) and 'selector' in rule:
                        failed_patterns.add(rule['selector'])
            
            # Filter out failed patterns from optimized rules
            for field in optimized_rules:
                optimized_rules[field] = [
                    rule for rule in optimized_rules[field]
                    if (isinstance(rule, str) and rule not in failed_patterns) or
                       (isinstance(rule, dict) and rule.get('selector') not in failed_patterns)
                ]
        
        return optimized_rules
    
    def generate_configuration_template(self, website_type: str, use_case: str) -> Dict[str, Any]:
        """
        Generate a configuration template for common use cases.
        
        Args:
            website_type: Type of website (news, e_commerce, etc.)
            use_case: Specific use case (price_monitoring, news_aggregation, etc.)
            
        Returns:
            Configuration template
        """
        templates = {
            'news_aggregation': {
                'description': 'Monitor news websites for new articles',
                'extraction_rules': {
                    'title': {'selector': 'h1, .title, .headline', 'attribute': 'text'},
                    'content': {'selector': '.content, .article-body, article p', 'attribute': 'text'},
                    'author': {'selector': '.author, .byline', 'attribute': 'text'},
                    'date': {'selector': '.date, .published, time', 'attribute': 'text'},
                    'url': {'selector': 'link[rel="canonical"]', 'attribute': 'href'}
                },
                'positive_actions': [
                    {'type': 'email', 'template': 'news_digest'},
                    {'type': 'webhook', 'url': 'https://example.com/webhook'}
                ],
                'schedule': 'daily'
            },
            'price_monitoring': {
                'description': 'Monitor product prices for changes',
                'extraction_rules': {
                    'product_name': {'selector': 'h1, .product-title', 'attribute': 'text'},
                    'price': {'selector': '.price, .cost', 'attribute': 'text'},
                    'availability': {'selector': '.stock, .availability', 'attribute': 'text'},
                    'rating': {'selector': '.rating, .stars', 'attribute': 'text'}
                },
                'positive_actions': [
                    {'type': 'price_alert', 'threshold': 10, 'direction': 'decrease'},
                    {'type': 'email', 'template': 'price_change'}
                ],
                'schedule': 'hourly'
            },
            'content_monitoring': {
                'description': 'Monitor websites for new content or changes',
                'extraction_rules': {
                    'title': {'selector': 'h1, .title', 'attribute': 'text'},
                    'content': {'selector': '.content, .main', 'attribute': 'text'},
                    'last_updated': {'selector': '.updated, .modified', 'attribute': 'text'}
                },
                'positive_actions': [
                    {'type': 'notification', 'message': 'New content detected'},
                    {'type': 'webhook', 'url': 'https://example.com/content-webhook'}
                ],
                'schedule': 'daily'
            }
        }
        
        return templates.get(use_case, {})
    
    def get_training_session(self, session_id: str) -> Optional[TrainingSession]:
        """Get a training session by ID."""
        return self.training_sessions.get(session_id)
    
    def list_training_sessions(self, agent_id: int) -> List[TrainingSession]:
        """List all training sessions for an agent."""
        return [
            session for session in self.training_sessions.values()
            if session.agent_id == agent_id
        ]

# Global trainer instance
agent_trainer = AgentTrainer()

