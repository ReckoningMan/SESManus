from flask import Blueprint, jsonify, request
from src.agent_trainer import agent_trainer, UIAction
from src.models.user import Agent, db
from datetime import datetime

training_bp = Blueprint('training', __name__)

@training_bp.route('/training/sessions', methods=['POST'])
def start_training_session():
    """Start a new training session for an agent."""
    data = request.json
    agent_id = data.get('agent_id')
    url = data.get('url')
    
    if not agent_id or not url:
        return jsonify({'error': 'Agent ID and URL are required'}), 400
    
    # Verify agent exists
    agent = Agent.query.get_or_404(agent_id)
    
    session_id = agent_trainer.start_training_session(agent_id, url)
    
    return jsonify({
        'session_id': session_id,
        'agent_id': agent_id,
        'url': url,
        'status': 'started',
        'created_at': datetime.utcnow().isoformat()
    }), 201

@training_bp.route('/training/sessions/<session_id>/actions', methods=['POST'])
def record_action(session_id):
    """Record a UI action in a training session."""
    data = request.json
    
    # Validate required fields
    action_type = data.get('action_type')
    selector = data.get('selector')
    
    if not action_type or not selector:
        return jsonify({'error': 'Action type and selector are required'}), 400
    
    # Create UI action
    action = UIAction(
        action_type=action_type,
        selector=selector,
        value=data.get('value'),
        coordinates=data.get('coordinates'),
        description=data.get('description')
    )
    
    success = agent_trainer.record_action(session_id, action)
    
    if not success:
        return jsonify({'error': 'Training session not found'}), 404
    
    return jsonify({
        'status': 'recorded',
        'action': {
            'action_type': action.action_type,
            'selector': action.selector,
            'value': action.value,
            'coordinates': action.coordinates,
            'description': action.description,
            'timestamp': action.timestamp
        }
    }), 201

@training_bp.route('/training/sessions/<session_id>/complete', methods=['POST'])
def complete_training_session(session_id):
    """Complete a training session and save learned patterns."""
    data = request.json
    
    extraction_rules = data.get('extraction_rules', {})
    
    success = agent_trainer.complete_training_session(session_id, extraction_rules)
    
    if not success:
        return jsonify({'error': 'Training session not found'}), 404
    
    session = agent_trainer.get_training_session(session_id)
    
    return jsonify({
        'status': 'completed',
        'session_id': session_id,
        'actions_recorded': len(session.actions),
        'extraction_rules': extraction_rules,
        'completed_at': datetime.utcnow().isoformat()
    })

@training_bp.route('/training/sessions/<session_id>', methods=['GET'])
def get_training_session(session_id):
    """Get details of a training session."""
    
    session = agent_trainer.get_training_session(session_id)
    
    if not session:
        return jsonify({'error': 'Training session not found'}), 404
    
    return jsonify({
        'session_id': session.session_id,
        'agent_id': session.agent_id,
        'url': session.url,
        'created_at': session.created_at,
        'completed': session.completed,
        'actions_count': len(session.actions),
        'actions': [
            {
                'action_type': action.action_type,
                'selector': action.selector,
                'value': action.value,
                'coordinates': action.coordinates,
                'description': action.description,
                'timestamp': action.timestamp
            }
            for action in session.actions
        ],
        'extraction_rules': session.extraction_rules
    })

@training_bp.route('/training/agents/<int:agent_id>/sessions', methods=['GET'])
def list_agent_training_sessions(agent_id):
    """List all training sessions for an agent."""
    # Verify agent exists
    agent = Agent.query.get_or_404(agent_id)
    
    sessions = agent_trainer.list_training_sessions(agent_id)
    
    return jsonify([
        {
            'session_id': session.session_id,
            'url': session.url,
            'created_at': session.created_at,
            'completed': session.completed,
            'actions_count': len(session.actions)
        }
        for session in sessions
    ])

@training_bp.route('/training/suggest-rules', methods=['POST'])
def suggest_extraction_rules():
    """Suggest extraction rules based on URL and content analysis."""
    data = request.json
    url = data.get('url')
    html_content = data.get('html_content')
    
    if not url or not html_content:
        return jsonify({'error': 'URL and HTML content are required'}), 400
    
    suggestions = agent_trainer.suggest_extraction_rules(url, html_content)
    
    return jsonify({
        'url': url,
        'suggestions': suggestions,
        'generated_at': datetime.utcnow().isoformat()
    })

@training_bp.route('/training/templates/<template_type>', methods=['GET'])
def get_configuration_template(template_type):
    """Get a configuration template for a specific use case."""
    website_type = request.args.get('website_type', 'general')
    
    template = agent_trainer.generate_configuration_template(website_type, template_type)
    
    if not template:
        return jsonify({'error': 'Template not found'}), 404
    
    return jsonify({
        'template_type': template_type,
        'website_type': website_type,
        'template': template,
        'generated_at': datetime.utcnow().isoformat()
    })

@training_bp.route('/training/templates', methods=['GET'])
def list_available_templates():
    """List all available configuration templates."""
    templates = [
        {
            'type': 'news_aggregation',
            'name': 'News Aggregation',
            'description': 'Monitor news websites for new articles and create daily digests'
        },
        {
            'type': 'price_monitoring',
            'name': 'Price Monitoring',
            'description': 'Track product prices and get alerts on price changes'
        },
        {
            'type': 'content_monitoring',
            'name': 'Content Monitoring',
            'description': 'Monitor websites for new content or changes'
        }
    ]
    
    return jsonify({
        'templates': templates,
        'count': len(templates)
    })

@training_bp.route('/training/agents/<int:agent_id>/optimize', methods=['POST'])
def optimize_agent_rules(agent_id):
    """Optimize extraction rules based on feedback data."""
    # Verify agent exists
    agent = Agent.query.get_or_404(agent_id)
    
    data = request.json
    feedback_data = data.get('feedback_data', [])
    
    optimized_rules = agent_trainer.optimize_extraction_rules(agent_id, feedback_data)
    
    return jsonify({
        'agent_id': agent_id,
        'optimized_rules': optimized_rules,
        'feedback_entries_processed': len(feedback_data),
        'optimized_at': datetime.utcnow().isoformat()
    })

@training_bp.route('/training/patterns', methods=['GET'])
def get_common_patterns():
    """Get common extraction patterns for different website types."""
    return jsonify({
        'patterns': agent_trainer.common_patterns,
        'website_types': list(agent_trainer.common_patterns.keys())
    })

